#--- START OF MODIFIED FILE takeImage.py ---

import csv
import os, cv2
# import numpy as np # Not used directly here
# import pandas as pd # Not used directly here
# import datetime # Not used directly here
# import time # Not used directly here


# take Image of user
def TakeImage(l1, l2, haarcasecade_path, trainimage_path, message, err_screen,text_to_speech):
    if (l1 == "") and (l2==""):
        t='Please Enter the your Enrollment Number and Name.'
        text_to_speech(t)
        err_screen() # Show error screen as well
        return # Exit function
    elif l1=='':
        t='Please Enter the your Enrollment Number.'
        text_to_speech(t)
        err_screen() 
        return
    elif l2 == "":
        t='Please Enter the your Name.'
        text_to_speech(t)
        err_screen()
        return
    else:
        try:
            cam = cv2.VideoCapture(0)
            if not cam.isOpened():
                # Handle camera not opening
                message.configure(text="Error: Could not open camera.")
                text_to_speech("Error: Could not open camera.")
                return

            detector = cv2.CascadeClassifier(haarcasecade_path)
            Enrollment = l1
            Name = l2
            sampleNum = 0
            
            # Path for training images for this student
            # Ensure trainimage_path itself exists (usually done in attendance.py)
            if not os.path.exists(trainimage_path):
                os.makedirs(trainimage_path)
            
            directory = Enrollment + "_" + Name
            path = os.path.join(trainimage_path, directory)
            
            if not os.path.exists(path):
                os.makedirs(path) # Use makedirs for nested paths if needed, though here it's one level
            else: # If student directory already exists
                # Decide policy: overwrite, error, or add more?
                # For now, let's assume it's an error or prompt for overwrite later.
                # Simplified: Let it proceed but it might mix images if IDs are reused with different names.
                # A better approach would be to clear the folder or warn.
                # For this modification, we focus on attendance, so keeping this part simple.
                pass


            while True:
                ret, img = cam.read()
                if not ret:
                    message.configure(text="Error: Failed to capture image from camera.")
                    text_to_speech("Error: Failed to capture image from camera.")
                    break 
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = detector.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    sampleNum = sampleNum + 1
                    # Save image with a clear naming convention
                    # Make sure path and filename construction is robust
                    img_name = f"{Name}_{Enrollment}_{str(sampleNum)}.jpg"
                    img_path = os.path.join(path, img_name)
                    
                    cv2.imwrite(img_path, gray[y : y + h, x : x + w])
                    cv2.imshow("Frame", img)
                
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
                elif sampleNum >= 50: # Capture 50 samples
                    break
            
            cam.release()
            cv2.destroyAllWindows()
            
            row = [Enrollment, Name]
            
            # Student details file path
            # Ensure StudentDetails directory exists
            s_details_dir = "StudentDetails"
            if not os.path.exists(s_details_dir):
                os.makedirs(s_details_dir)
            s_details_path = os.path.join(s_details_dir, "studentdetails.csv")

            file_exists = os.path.isfile(s_details_path)
            
            # Open in append mode, create if not exists. `newline=''` for csv.
            with open(s_details_path, "a+", newline="") as csvFile:
                writer = csv.writer(csvFile, delimiter=",")
                # If file is new or empty, write the header
                if not file_exists or os.path.getsize(s_details_path) == 0:
                    writer.writerow(["Enrollment", "Name"])
                writer.writerow(row)
            
            res = "Images Saved for ER No:" + Enrollment + " Name:" + Name
            message.configure(text=res)
            text_to_speech(res)
            
        except FileExistsError as F: # This might catch os.mkdir(path) if path is a file.
                                     # os.makedirs(path, exist_ok=True) is safer for directory creation.
            # This specific FileExistsError for os.mkdir(path) is less likely if Enrollment_Name is unique
            # If it's about student data already existing, the check should be against studentdetails.csv
            res_text = "Student Data (images or details) might already exist or error creating folder."
            message.configure(text=res_text)
            text_to_speech(res_text)
        except Exception as e: # Catch other potential errors
            error_msg = f"An error occurred: {e}"
            message.configure(text=error_msg)
            text_to_speech(error_msg)
            if 'cam' in locals() and cam.isOpened():
                cam.release()
            cv2.destroyAllWindows()

#--- END OF MODIFIED FILE takeImage.py ---